Put all these files into an archieve.
Which initiates "Shortcutter.bat" after extracting these files.
I've used WinRar For that.
